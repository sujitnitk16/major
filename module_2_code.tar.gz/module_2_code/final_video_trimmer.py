def Trime_video(video_file):
	import os
	import get_time_duration_of_video
	p=get_time_duration_of_video.trime_video(video_file)
	i=0
	k=p/10
	#print ('k=',k)
	j=p/10
	f=video_file.split('.')
	
	print f[0]
	while (j-0.5<=p):
		if not os.path.exists("divides_all_videos/"+f[0]+'_'+str(i)):
        				os.makedirs("divides_all_videos/"+f[0]+'_'+str(i))
		from moviepy.video.io.ffmpeg_tools import ffmpeg_extract_subclip
		ffmpeg_extract_subclip(video_file, i, j, targetname="divides_all_videos/"+f[0]+'_'+str(i)+'/'+f[0]+'_'+str(i)+".mp4")
		i=int(j)
		j=j+k
	print j
	
