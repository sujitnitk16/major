

find . -maxdepth 1 -type f -size 0 -delete
