import os 
import glob
for path in glob.glob('divides_all_videos_faces/*'): 
	#path='divides_all_videos/00387_95'  
	while(True):  
	    if(os.path.isdir(path)):  
	      break  
	    else:  
	      print("please enter a valid path ") 
	for root,dirs,files in os.walk(path):  
	 for name in files:  
	  filename=os.path.join(root,name)  
	  if os.stat(filename).st_size==0:  
	   #print(" Removing ",filename)  
	   os.remove(filename)
