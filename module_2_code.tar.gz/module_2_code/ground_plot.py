def plot_result_g(bars1, bars2, bars3, bars4):
	import numpy as np
	import matplotlib.pyplot as plt
	from clint.textui import colored
	# set width of bar
	barWidth = 0.25
	 
	# set height of bar
	#bars1 = [60, 86, 91.23, 98.56,91] # More_Happy
	#bars2 = [10, 20, 30, 40,3]        # Happy
	#bars3 = [10, 20, 30, 40,5]	  # Bored
	#bars4 = [10, 20, 30, 40,5]	  # More_Bored
	 
	# Set position of bar on X axis
	r1 = np.arange(len(bars1))
	r2 = [x + barWidth for x in r1]
	r3 = [x + barWidth for x in r2]
	r4 = [x + barWidth for x in r3]
	 				 
	# Make the plot
	plt.bar(r1, bars1, color='#7f6d5f', width=barWidth, edgecolor='white', label='More_Happy')
	plt.bar(r2, bars2, color='red', width=barWidth, edgecolor='white', label='Happy')
	plt.bar(r3, bars4, color='blue', width=barWidth, edgecolor='white', label='Bored')
	plt.bar(r4, bars3, color='#2d7f5e', width=barWidth, edgecolor='white', label='More_Bored')

	# Add xticks on the middle of the group bars
	plt.xlabel('Fixed Time Period', fontweight='bold')
	plt.xticks([r + barWidth for r in range(len(bars1))], ['A', 'B', 'C', 'D', 'E','F', 'G', 'H', 'I','J'])
	 
	# Create legend & Show graphic
	plt.legend()
	plt.savefig('ground.png')
	plt.show()
'''
bars1 = [60, 86, 91.23, 98.56,91] # More_Happy
bars2 = [10, 20, 30, 40,3]        # Happy
bars3 = [10, 20, 30, 40,5]	  # Bored
bars4 = [10, 20, 30, 40,5]	  # More_Bored
plot_result_g(bars1, bars2, bars3, bars4)
'''

