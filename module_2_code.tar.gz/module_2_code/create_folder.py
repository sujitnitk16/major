import os
if not os.path.exists('test'):
        os.makedirs('test')
	video_file='ssss.mp4'
	f=video_file.split('.')
	print f[0]
