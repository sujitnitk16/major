from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from functools import reduce
import glob
import argparse
import os.path
import re
import sys
import tarfile

import numpy as np
from six.moves import urllib
import tensorflow as tf

More_Happy=[]
More_Happy.append(0)
Happy=[]
Happy.append(0)
Bored=[]
Bored.append(0)
More_Bored=[]
More_Bored.append(0)
More_Happy_temp=[]
Happy_temp=[]
Bored_temp=[]
More_Bored_temp=[]



c=0;
list=[];

FLAGS = None

def create_graph():
  """Creates a graph from saved GraphDef file and returns a saver."""
  # Creates graph from saved graph_def.pb.
  
  with tf.gfile.FastGFile('tf_files/retrained_graph.pb', 'rb') as f:
	    graph_def = tf.GraphDef()
	    graph_def.ParseFromString(f.read())
	    _ = tf.import_graph_def(graph_def, name='')


def run_inference_on_image(image):
  """Runs inference on an image.

  Args:
    image: Image file name.

  Returns:
    Nothing
  """
  if not tf.gfile.Exists(image):
    tf.logging.fatal('File does not exist %s', image)
  image_data = tf.gfile.FastGFile(image, 'rb').read()

  # Creates graph from saved GraphDef.
  create_graph()

  with tf.Session() as sess:
    # Some useful tensors:
    # 'softmax:0': A tensor containing the normalized prediction across
    #   1000 labels.
    # 'pool_3:0': A tensor containing the next-to-last layer containing 2048
    #   float description of the image.
    # 'DecodeJpeg/contents:0': A tensor containing a string providing JPEG
    #   encoding of the image.
    # Runs the softmax tensor by feeding the image_data as input to the graph.
    softmax_tensor = sess.graph.get_tensor_by_name('final_result:0')
    predictions = sess.run(softmax_tensor,
                           {'DecodeJpeg/contents:0': image_data})
    predictions = np.squeeze(predictions)

    # Creates node ID --> English string lookup.
    #node_lookup = NodeLookup()
    label_lines = [line.rstrip() for line 
				   in tf.gfile.GFile('tf_files/retrained_labels.txt')]

    top_k = predictions.argsort()[-FLAGS.num_top_predictions:][::-1]
    a=top_k[0]
    
    list.append(a);
    if a==0:
        prob=predictions[a]
        prob_perc=prob*100
        More_Bored.append(prob_perc)
    elif a==1:
        prob=predictions[a]
        prob_perc=prob*100
        Happy.append(prob_perc)
    elif a==2:
        prob=predictions[a]
        prob_perc=prob*100
        More_Happy.append(prob_perc)
    elif a==3:
        prob=predictions[a]
        prob_perc=prob*100
        Bored.append(prob_perc)
        #print ('More_Happy', More_Happy)

    print ("1st_label :",label_lines[a])
    for node_id in top_k:
        mood_string = label_lines[node_id]
        score = predictions[node_id]
	#c=c+1;
        print('%s (score = %.3f)' % (mood_string, score))


def main(_):
  c=0;
  import os
  top='divides_all_videos_faces'
  print (top)
  for root, dirs, files in os.walk(top, topdown=False):
    for name in dirs:
          del More_Happy[ 0:len(More_Happy) ]
          del Happy[ 0:len(Happy) ]
          del Bored[ 0:len(Bored) ]
          del More_Bored[ 0:len(More_Bored) ]
        #res( os.path.join(root, name))
          for filename in glob.glob(os.path.join(root, name)+'/*.jpg'):
		#image_data = tf.gfile.FastGFile(filename, 'rb').read()
                image = (FLAGS.image_file if FLAGS.image_file else
			   os.path.join(filename))
                with tf.Graph().as_default():
                        c=c+1
                        print (c)
                        run_inference_on_image(image)
	  
	  #print (More_Happy)
          if len(More_Happy)>1:
              p=reduce(lambda x, y: x + y, More_Happy) / (len(More_Happy))
              More_Happy_temp.append(p)
          else:
               More_Happy_temp.append(0)
          print (Happy)
          if len(Happy)>1:
                p=reduce(lambda x, y: x + y, Happy) / (len(Happy))
                Happy_temp.append(p)
          else : Happy_temp.append(0)
          print (Bored)
          if len(Bored)>1:
              p=reduce(lambda x, y: x + y, Bored) / (len(Bored))
              Bored_temp.append(p)
          else : Bored_temp.append(0)
          print (More_Bored)
          if len(More_Bored)>1:
                 p=reduce(lambda x, y: x + y, More_Bored) / (len(More_Bored))
                 More_Bored_temp.append(p)
          else: More_Bored_temp.append(0)
          label_lines = [line.rstrip() for line 
					   in tf.gfile.GFile('tf_files/retrained_labels.txt')]

          print("Final Prediction mood of video:")
          for i in range(0,len(set(list))):
                a=str(100*(list.count(i)/len(list)))
                print(label_lines[i],a+'%')		
                f=max(list,key=list.count)
          print("Final Mood Predicted :",label_lines[f])
	  
  #plot
  result_pl=[]
  if  len(More_Happy_temp)==0:
     p=0
  else:
          p=reduce(lambda x, y: x + y, More_Happy_temp) / len(More_Happy_temp)
          result_pl.append(p)
  if  len(Happy_temp)==0:
      p=0
  else:
        p=reduce(lambda x, y: x + y, Happy_temp) / len(Happy_temp)
        result_pl.append(p)
  if  len(Bored_temp)==0:
        p=0
  else:
        p=reduce(lambda x, y: x + y, Bored_temp) / len(Bored_temp)
        result_pl.append(p)
  if  len(More_Bored_temp)==0:
       p=0
  else:
         p=reduce(lambda x, y: x + y, More_Bored_temp) / len(More_Bored_temp)
         result_pl.append(p)
  print (result_pl)
  print (More_Happy_temp)
  print (Happy_temp)
  print (Bored_temp)
  print (More_Bored_temp)
  import result_plot
  result_plot.result(result_pl)
  import ground_plot
  ground_plot.plot_result_g(More_Happy_temp, Happy_temp, Bored_temp, More_Bored_temp)


if __name__ == '__main__':
  parser = argparse.ArgumentParser()
  # classify_image_graph_def.pb:
  #   Binary representation of the GraphDef protocol buffer.
  #   Text representation of a protocol buffer mapping a label to synset ID.
  parser.add_argument(
      '--model_dir',
      type=str,
      default='/tmp/imagenet',
      
  )
  parser.add_argument(
      '--image_file',
      type=str,
      default='',
      help='Absolute path to image file.'
  )
  parser.add_argument(
      '--num_top_predictions',
      type=int,
      default=5,
      help='Display this many predictions.'
  )
  FLAGS, unparsed = parser.parse_known_args()
  tf.app.run(main=main, argv=[sys.argv[0]] + unparsed)
