from __future__ import division
import tensorflow as tf, sys
from datetime import datetime
import glob

start_time = datetime.now()
More_Happy=[]
Happy=[]
Bored=[]
More_Bored=[]
c=0;
list=[];
# Read in the image_data

for filename in glob.glob('Faces/*.jpg'):
	image_data = tf.gfile.FastGFile(filename, 'rb').read()
	print(filename)
	# Loads label file, strips off carriage return
	label_lines = [line.rstrip() for line 
		           in tf.gfile.GFile('retrained_labels.txt')]

	# Unpersists graph from file
	with tf.gfile.FastGFile('retrained_graph.pb', 'rb') as f:
	    graph_def = tf.GraphDef()
	    graph_def.ParseFromString(f.read())
	    _ = tf.import_graph_def(graph_def, name='')

	with tf.Session() as sess:
	    # Feed the image_data as input to the graph and get first prediction
	    softmax_tensor = sess.graph.get_tensor_by_name('final_result:0')
	    
	    predictions = sess.run(softmax_tensor, \
		     {'DecodeJpeg/contents:0': image_data})
	    
	    # Sort to show labels of first prediction in order of confidence
	    top_k = predictions[0].argsort()[-len(predictions[0]):][::-1]
	    a=top_k[0]
	    print a
            print("predicted Mood is :",a,label_lines[a])
	    list.append(a);
	    if a==0:
		prob=predictions[0][a]
		prob_perc=prob*100
		More_Happy.append(prob_perc)
	    elif a==1:
		prob=predictions[0][a]
		prob_perc=prob*100
		Happy.append(prob_perc)
	    elif a==2:
		prob=predictions[0][a]
		prob_perc=prob*100
		Bored.append(prob_perc)
	    elif a==3:
		prob=predictions[0][a]
		prob_perc=prob*100
		More_Bored.append(prob_perc)
		print ('More_Happy', More_Happy)
	    print("Analyze emotion using (Face and posture)")
	    for node_id in top_k:
		human_string = label_lines[node_id]
		score = predictions[0][node_id]
		c=c+1;
		print('%s (score = %.3f)' % (human_string, score))


	end_time = datetime.now()
	print('Duration: {}'.format(end_time - start_time))
print
print("Final Prediction mood of video:")
for i in range(0,len(set(list))):
	a=str(100*(list.count(i)/len(list)))
	#print(label_lines[i],a+'%')		
f=max(list,key=list.count)
print("Final Mood Predicted :",label_lines[f])
print More_Happy
print Happy
print Bored
print More_Bored

result_pl=[]
if  len(More_Happy)==0:
	p=0
else:
	p=reduce(lambda x, y: x + y, More_Happy) / len(More_Happy)
result_pl.append(p)
if  len(Happy)==0:
	p=0
else:
	p=reduce(lambda x, y: x + y, Happy) / len(Happy)
result_pl.append(p)
if  len(Bored)==0:
	p=0
else:
	p=reduce(lambda x, y: x + y, Bored) / len(Bored)
result_pl.append(p)
if  len(More_Bored)==0:
	p=0
else:
	p=reduce(lambda x, y: x + y, More_Bored) / len(More_Bored)
result_pl.append(p)
print result_pl

import result_plot
result_plot.result(result_pl)



