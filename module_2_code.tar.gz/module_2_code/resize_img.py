from PIL import Image
import glob
import time
import os
size=(850, 550)
#def video_to_frames(input_loc, output_loc):
for filename in glob.glob('divides_all_videos/*/*.jpg'):
    s=filename.split('/')
    s1=s[2].split('.')
    p=s[1]
    #print s[1]
    original_image = Image.open(filename)
    width, height = original_image.size
    #print('The original image size is {wide} wide x {height} '
    #      'high'.format(wide=width, height=height))
 
    resized_image = original_image.resize(size)
    width, height = resized_image.size
    print('The resized image size is {wide} wide x {height} '
          'high'.format(wide=width, height=height))
    #resized_image.show()
    resized_image.save('divides_all_videos/'+p+"/"+s1[0]+'.jpg')
'''
if __name__ == '__main__':
    resize_image(input_image_path='optimized.jpg',
                 output_image_path='small.jpg',
                 size=(850, 550))
'''
print ('Resize is Done !')
