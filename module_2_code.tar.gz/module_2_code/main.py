import final_video_trimmer
final_video_trimmer.Trime_video('00387.MTS')
import extract_frame
#import rotate
#import resize_img
import delete_zero_byte_file
#import face_detct
#import delete_zero_byte_file_face
import final_mood_analysis_without_memory_error
#Till now successfull.
'''
import mood_analysis

# mood_analysis: stored all four class predictive-probabilities in a respective-list[] and take average of all list and pass it in ground_plot.py and result_plot.py 
'''
