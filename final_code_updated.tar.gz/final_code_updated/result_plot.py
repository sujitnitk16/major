def result(sizes):
	import matplotlib.pyplot as plt
	labels = ['More_Happy', 'Happy','Bored','More_Bored']
	#sizes = [45.23, 20.6, 11.7, 23.3]
	colors = ['yellowgreen', 'gold', 'lightskyblue', 'lightcoral']
	plt.pie(sizes, colors=colors, autopct='%1.2f%%', shadow=True, wedgeprops = { 'linewidth' : 3, 'edgecolor' : "black" }, startangle=90)
	patches, texts = plt.pie(sizes, colors=colors, shadow=True, startangle=90)
	plt.legend(patches, labels, loc="best")
	plt.axis('equal')
	plt.tight_layout()
	plt.savefig('foo.png')
	plt.show()

