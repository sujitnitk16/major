def trime_video(vedio_file):
	import moviepy.editor as mp
	duration =  mp.VideoFileClip(vedio_file).duration
	#get_duration=int(duration)
	#b=duration/10
        print (duration)
	return duration
	
