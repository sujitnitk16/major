from moviepy.editor import *
clip = VideoFileClip("test_video/20130410172030.m2ts").cutout(6, 9)
clip.write_videofile("test1.mp4")
