import glob
import cv2
import time
import os
output_loc = 'divides_all_videos/'
#def video_to_frames(input_loc, output_loc):
for filename in glob.glob('divides_all_videos/*/*.*'):
    """Function to extract frames from input video file
    and save them as separate frames in an output directory.
    Args:
        input_loc: Input video file.
        output_loc: Output directory to save the frames.
    Returns:
        None
    """
    # Log the time
    print(filename)
    s=filename.split('/')
    #print s
    s1=s[2].split('.')
    p=s[1]
    
    #print (s[0])
    #print (s1[0])
    if (str(s1[1])=='mp4' or str(s1[1])=='m2ts'):
	    time_start = time.time()
	    # Start capturing the feed
	    cap = cv2.VideoCapture(filename)
	    # Find the number of frames
	    video_length = int(cap.get(cv2.CAP_PROP_FRAME_COUNT)) - 1
	    print ("Number of frames: ", video_length)
	    count = 0
	    print ("Converting video..\n")
	    # Start converting the video
	    while cap.isOpened():
		# Extract the frame
		ret, frame = cap.read()
		# Write the results back to output location.
		#cv2.imwrite(output_loc +"/%#05d.jpg" % (count+1), frame)
		cv2.imwrite('divides_all_videos/'+p+"/"+s1[0]+"_%d.jpg" % count,frame)
		count = count + 1
		# If there are no more frames left
		if (count > (video_length-1)):
		    # Log the time again
		    time_end = time.time()
		    # Release the feed
		    cap.release()
		    # Print stats
		    print ("Done extracting frames.\n%d frames extracted" % count)
		    print ("It took %d seconds forconversion." % (time_end-time_start))
		    break



