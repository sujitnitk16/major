from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
import glob
import argparse
import os.path
import re
import sys
import tarfile

import numpy as np
from six.moves import urllib
import tensorflow as tf

FLAGS = None

def create_graph():
  """Creates a graph from saved GraphDef file and returns a saver."""
  # Creates graph from saved graph_def.pb.
  
  with tf.gfile.FastGFile('tf_files/retrained_graph.pb', 'rb') as f:
	    graph_def = tf.GraphDef()
	    graph_def.ParseFromString(f.read())
	    _ = tf.import_graph_def(graph_def, name='')


def run_inference_on_image(image):
  """Runs inference on an image.

  Args:
    image: Image file name.

  Returns:
    Nothing
  """
  if not tf.gfile.Exists(image):
    tf.logging.fatal('File does not exist %s', image)
  image_data = tf.gfile.FastGFile(image, 'rb').read()

  # Creates graph from saved GraphDef.
  create_graph()

  with tf.Session() as sess:
    # Some useful tensors:
    # 'softmax:0': A tensor containing the normalized prediction across
    #   1000 labels.
    # 'pool_3:0': A tensor containing the next-to-last layer containing 2048
    #   float description of the image.
    # 'DecodeJpeg/contents:0': A tensor containing a string providing JPEG
    #   encoding of the image.
    # Runs the softmax tensor by feeding the image_data as input to the graph.
    softmax_tensor = sess.graph.get_tensor_by_name('final_result:0')
    predictions = sess.run(softmax_tensor,
                           {'DecodeJpeg/contents:0': image_data})
    predictions = np.squeeze(predictions)

    # Creates node ID --> English string lookup.
    #node_lookup = NodeLookup()
    label_lines = [line.rstrip() for line 
				   in tf.gfile.GFile('tf_files/retrained_labels.txt')]

    top_k = predictions.argsort()[-FLAGS.num_top_predictions:][::-1]
    a=top_k[0]
    #print (top_k)
    #print (predictions)
    #print (a)
    print (label_lines[a])
    for node_id in top_k:
                        #print (node_id)
			human_string = label_lines[node_id]
			score = predictions[node_id]
			#c=c+1;
			print('%s (score = %.5f)' % (human_string, score))

    return label_lines[a]
    #current_features = run_inference_on_image(images_folder+"/"+image)

def main(_):
        import glob
	import sys
	import dlib
	import cv2
	from skimage import io
	from datetime import datetime
	j=0
	def draw_text(img, text, x,y,t,b):
	    cv2.putText(img, text, (x,y), cv2.FONT_HERSHEY_COMPLEX_SMALL, 1, (0, 255, 0), 1)
	start_time = datetime.now()
	cnn_face_detector = dlib.cnn_face_detection_model_v1('mmod_human_face_detector.dat')
	win = dlib.image_window()

	for f in glob.glob('image/*.*'):
	    print("Processing file: {}".format(f))
	    img = io.imread(f)
	    # The 1 in the second argument indicates that we should upsample the image
	    # 1 time.  This will make everything bigger and allow us to detect more
	    # faces.
	    dets = cnn_face_detector(img, 1)
	    img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
	   
	    '''
	    This detector returns a mmod_rectangles object. This object contains a list of mmod_rectangle objects.
	    These objects can be accessed by simply iterating over the mmod_rectangles object
	    The mmod_rectangle object has two member variables, a dlib.rectangle object, and a confidence score.
	    
	    It is also possible to pass a list of images to the detector.
		- like this: dets = cnn_face_detector([image list], upsample_num, batch_size = 128)
	    In this case it will return a mmod_rectangless object.
	    This object behaves just like a list of lists and can be iterated over.
	    '''
	    print("Number of faces detected: {}".format(len(dets)))
	    for i, d in enumerate(dets):
		print("Detection {}: Left: {} Top: {} Right: {} Bottom: {} Confidence: {}".format(
		    i, d.rect.left(), d.rect.top(), d.rect.right(), d.rect.bottom(), d.confidence))
		#rect=[d.rect.left(), d.rect.top(), d.rect.right(), d.rect.bottom()]
		#print ("Detection {}: Left: {} Top: {} Right: {} Bottom: {}".format(i, d.left(), d.top(), d.right(), d.bottom()))
		cv2.rectangle(img, (d.rect.left(), d.rect.top()), (d.rect.right(), d.rect.bottom()), (0,0,255), 2)
		crop = img[d.rect.top():d.rect.bottom(), d.rect.left():d.rect.right()]
		face_file_name = "person/r_"+str(j)+".jpg"
		cv2.imwrite(face_file_name, crop)
		j=j+1
                image = (FLAGS.image_file if FLAGS.image_file else
		   os.path.join(face_file_name))
          	with tf.Graph().as_default():
	  		check=run_inference_on_image(face_file_name)
		draw_text(img,check,d.rect.left(), d.rect.top(), d.rect.right(), d.rect.bottom())
		cv2.imwrite(face_file_name, crop)
	    	rects = dlib.rectangles()
	    	rects.extend([d.rect for d in dets])
	    	cv2.imshow("img",img)
	    #win.clear_overlay()
	    #win.set_image(img)
	    #win.add_overlay(rects)
                s=f.split('/')
	    	s1=s[1].split('.')
	    	cv2.imwrite('labeled_images_output/'+s1[0]+'labeled'+'.jpg', img)
	    	
	end_time = datetime.now()
	print('Duration: {}'.format(end_time - start_time))


if __name__ == '__main__':
  parser = argparse.ArgumentParser()
  # classify_image_graph_def.pb:
  #   Binary representation of the GraphDef protocol buffer.
  #   Text representation of a protocol buffer mapping a label to synset ID.
  parser.add_argument(
      '--model_dir',
      type=str,
      default='/tmp/imagenet',
      
  )
  parser.add_argument(
      '--image_file',
      type=str,
      default='',
      help='Absolute path to image file.'
  )
  parser.add_argument(
      '--num_top_predictions',
      type=int,
      default=5,
      help='Display this many predictions.'
  )
  FLAGS, unparsed = parser.parse_known_args()
  tf.app.run(main=main, argv=[sys.argv[0]] + unparsed)
