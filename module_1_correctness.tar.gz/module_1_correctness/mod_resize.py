from PIL import Image
import glob
import time
import os
output_image_path = 'image/'
size=(850, 550)
#def video_to_frames(input_loc, output_loc):
for filename in glob.glob('image/*/*.jpg'):
    #print filename
    s=filename.split('/')
    s1=s[1]
    #print s1
    s=s[2].split('.')
    p=s[1]
    #print s[1]
    #print s[0]
    original_image = Image.open(filename)
    width, height = original_image.size
    print('The original image size is {wide} wide x {height} '
          'high'.format(wide=width, height=height))
 
    resized_image = original_image.resize(size)
    width, height = resized_image.size
    print('The resized image size is {wide} wide x {height} '
          'high'.format(wide=width, height=height))
    #resized_image.show()
    resized_image.save('image/'+s1+'/'+s[0]+'.'+s[1])
'''
if __name__ == '__main__':
    resize_image(input_image_path='optimized.jpg',
                 output_image_path='small.jpg',
                 size=(850, 550))
'''
