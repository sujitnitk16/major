from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
import glob
import argparse
import os.path
import re
import sys
import tarfile
import img_resize
import numpy as np
from six.moves import urllib
import tensorflow as tf
glist=[]
FLAGS = None

def create_graph():
  """Creates a graph from saved GraphDef file and returns a saver."""
  # Creates graph from saved graph_def.pb.
  
  with tf.gfile.FastGFile('tf_files/retrained_graph.pb', 'rb') as f:
	    graph_def = tf.GraphDef()
	    graph_def.ParseFromString(f.read())
	    _ = tf.import_graph_def(graph_def, name='')


def run_inference_on_image(image):
  """Runs inference on an image.

  Args:
    image: Image file name.

  Returns:
    Nothing
  """
  if not tf.gfile.Exists(image):
    tf.logging.fatal('File does not exist %s', image)
  image_data = tf.gfile.FastGFile(image, 'rb').read()

  # Creates graph from saved GraphDef.
  create_graph()
  list=[]
  with tf.Session() as sess:
    # Some useful tensors:
    # 'softmax:0': A tensor containing the normalized prediction across
    #   1000 labels.
    # 'pool_3:0': A tensor containing the next-to-last layer containing 2048
    #   float description of the image.
    # 'DecodeJpeg/contents:0': A tensor containing a string providing JPEG
    #   encoding of the image.
    # Runs the softmax tensor by feeding the image_data as input to the graph.
    softmax_tensor = sess.graph.get_tensor_by_name('final_result:0')
    predictions = sess.run(softmax_tensor,
                           {'DecodeJpeg/contents:0': image_data})
    predictions = np.squeeze(predictions)

    # Creates node ID --> English string lookup.
    #node_lookup = NodeLookup()
    label_lines = [line.rstrip() for line 
				   in tf.gfile.GFile('tf_files/retrained_labels.txt')]

    top_k = predictions.argsort()[-FLAGS.num_top_predictions:][::-1]
    a=top_k[0]
    #print (top_k)
    #print (predictions)
    #print (a)
    #glist.append(label_lines[a])
    #list.append(label_lines[a])
    #print(list)
    for node_id in top_k:
                        #print (node_id)
			human_string = label_lines[node_id]
			score = predictions[node_id]
			#c=c+1;
			print('%s (score = %.4f)' % (human_string, score))
			
    
    return label_lines[a], predictions[a]
    #current_features = run_inference_on_image(images_folder+"/"+image)
import xlsxwriter
from datetime import datetime
import glob
import os
import csv
from time import gmtime, strftime
def main(_):
   workbook = xlsxwriter.Workbook('Prasent_Students.xlsx')
   worksheet = workbook.add_worksheet()
   worksheet.set_column('A:A', 20)
   worksheet.set_column('B:B', 15)
   worksheet.set_column('C:C', 20)
   start_time = datetime.now()
   li = []
   list=[];
   i=0
   j=1
   k=1
   lis=[]
   c=0;
  #maybe_download_and_extract()
   for filename in glob.glob('person/*.jpg'):
	#image_data = tf.gfile.FastGFile(filename, 'rb').read()
	  image = (FLAGS.image_file if FLAGS.image_file else
		   os.path.join(filename))
          with tf.Graph().as_default():
                c=c+1
                check=[]
		check=run_inference_on_image(image)
                
                if(check[1])<0.45:
                                print("Unknown Student")
				#li.append('Unknown')
	     			worksheet.set_row(i, 70)
				worksheet.write('A'+str(j), 'Unknown')
				img=img_resize.resize(filename)
				img='image/'+filename.split('/')[1]
				#print img
				worksheet.insert_image('B'+str(j), img)
		                worksheet.write('C'+str(k), strftime("%d-%m-%Y %H:%M:%S", gmtime()))
				i=i+1
				j=j+1
		                k=k+1
			
		else:
                        if (check[0] in glist)==False:
 				glist.append(check[0])
			    	print("predicted Student is :",check[0])
			        list.append(check[0])
			    	#list.append(a);
				worksheet.set_row(i, 70)
				worksheet.write('A'+str(j), check[0])
				img=img_resize.resize(filename)
				img='image/'+filename.split('/')[1]
				#print img
				worksheet.insert_image('B'+str(j), img)
	                        worksheet.write('C'+str(k), strftime("%d-%m-%Y %H:%M:%S", gmtime()))
				#print(j)
				i=i+1
				j=j+1
	                	k=k+1
	  	#lis.append(run_inference_on_image(image))
   #print(lis[0][0],lis[0][1])
   #print(glist)
   output = []
   for x in list:
     if x not in output:
	output.append(x)


   count = 0
   for i in output:
    if count % 2 == 0:
	li.append(i)
    count += 1 
   #print ('Present Students :')
   #print ('\n'.join(li))
   print("Present student are in following list:")
   csvfile = 'Present_student.csv'
   print("saved in Present_student.csv file")
   print("saved in Present_student.xl-sheet file")
   with open(csvfile, "w") as output:
       writer = csv.writer(output, lineterminator='\n')
       for val in li:
	   writer.writerow([val])


if __name__ == '__main__':
  parser = argparse.ArgumentParser()
  # classify_image_graph_def.pb:
  #   Binary representation of the GraphDef protocol buffer.
  #   Text representation of a protocol buffer mapping a label to synset ID.
  parser.add_argument(
      '--model_dir',
      type=str,
      default='/tmp/imagenet',
      
  )
  parser.add_argument(
      '--image_file',
      type=str,
      default='',
      help='Absolute path to image file.'
  )
  parser.add_argument(
      '--num_top_predictions',
      type=int,
      default=5,
      help='Display this many predictions.'
  )
  FLAGS, unparsed = parser.parse_known_args()
  tf.app.run(main=main, argv=[sys.argv[0]] + unparsed)
